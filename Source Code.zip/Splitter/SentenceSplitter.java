package Splitter;

import com.aliasi.sentences.MedlineSentenceModel;
import com.aliasi.sentences.SentenceModel;

import com.aliasi.tokenizer.IndoEuropeanTokenizerFactory;
import com.aliasi.tokenizer.TokenizerFactory;
import com.aliasi.tokenizer.Tokenizer;

import com.aliasi.util.Files;

import java.io.BufferedReader;
import java.io.File;
import java.io.FileReader;
import java.io.IOException;

import java.util.ArrayList;
import java.util.Arrays;
import java.util.Iterator;
import java.util.LinkedHashMap;
import java.util.LinkedHashSet;
import java.util.List;
import java.util.Set;

/** Use SentenceModel to find sentence boundaries in text */
public class SentenceSplitter{

    static final TokenizerFactory TOKENIZER_FACTORY = IndoEuropeanTokenizerFactory.INSTANCE;
    static final SentenceModel SENTENCE_MODEL  = new MedlineSentenceModel();

    /*
     * Split the input abstract into sentences.
     */
    public LinkedHashMap<String, LinkedHashSet<String>> Splitter(File AbstractFile) throws IOException {
    	String pmid = AbstractFile.getName().substring(0,AbstractFile.getName().lastIndexOf("."));
    	BufferedReader br = new BufferedReader(new FileReader(AbstractFile));
		String textLine = null;
		
		LinkedHashSet<String> splitsentence = new LinkedHashSet<String>();
		LinkedHashMap<String, LinkedHashSet<String>> sentences_map = new LinkedHashMap<String, LinkedHashSet<String>>();
		splitsentence.clear();
		sentences_map.clear();
		
		
		while((textLine = br.readLine()) != null){
			List<String> tokenList = new ArrayList<String>();
			List<String> whiteList = new ArrayList<String>();
			Tokenizer tokenizer = TOKENIZER_FACTORY.tokenizer(textLine.toCharArray(),0,textLine.length());
			tokenizer.tokenize(tokenList,whiteList);
		
		
			String[] tokens = new String[tokenList.size()];
			String[] whites = new String[whiteList.size()];
			tokenList.toArray(tokens);
			whiteList.toArray(whites);
			int[] sentenceBoundaries = SENTENCE_MODEL.boundaryIndices(tokens,whites);
		
			
			int sentStartTok = 0;
			int sentEndTok = 0;
			
			System.out.println("sentenceBoundary : " + sentenceBoundaries.length);
			for (int i = 0; i < sentenceBoundaries.length; ++i) {
				String temp = "";
			    sentEndTok = sentenceBoundaries[i];
			    for (int j=sentStartTok; j<=sentEndTok; j++) {
			    	temp += tokens[j]+whites[j+1];
			    }
			    sentStartTok = sentEndTok+1;
			    splitsentence.add(temp);
			}
			sentences_map.put(pmid, splitsentence);
		}
		return sentences_map;
    }
}