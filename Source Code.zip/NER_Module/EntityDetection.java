package NER_Module;

import java.io.BufferedReader;
import java.io.BufferedWriter;
import java.io.File;
import java.io.FileReader;
import java.io.FileWriter;
import java.io.IOException;
import java.util.LinkedHashMap;
import java.util.LinkedHashSet;
import java.util.Map.Entry;

import javax.lang.model.AnnotatedConstruct;

import com.aliasi.chunk.Chunk;
import com.aliasi.chunk.Chunking;
import com.aliasi.dict.DictionaryEntry;
import com.aliasi.dict.ExactDictionaryChunker;
import com.aliasi.dict.MapDictionary;
import com.aliasi.tokenizer.IndoEuropeanTokenizerFactory;

import de.berlin.hu.chemspot.ChemSpot;
import de.berlin.hu.chemspot.ChemSpotFactory;
import de.berlin.hu.chemspot.Mention;

public class EntityDetection {


	public LinkedHashSet<String> NodeDectector(LinkedHashMap<String, LinkedHashSet<String>> splitSentence_for_each_line, ExactDictionaryChunker P_dictionaryChunkerTF, ChemSpot tagger) throws IOException {
		
		LinkedHashSet<String> sentence_units = new LinkedHashSet<String>();
		BufferedWriter cooccurrence = new BufferedWriter(new FileWriter("C:/Users/choi/Desktop/cwj/co-occurrences.txt", true));
    	LinkedHashSet<String> Ptemp_chunk_result = new LinkedHashSet<String>();
		LinkedHashSet<String> Pchunk_result = new LinkedHashSet<String>();
		LinkedHashSet<String> Cchunk_result = new LinkedHashSet<String>();
    	
		/*
		 * Node Detector 
		 */
		for(Entry<String,LinkedHashSet<String>> entry : splitSentence_for_each_line.entrySet()){ 
			
			String key = entry.getKey();
			LinkedHashSet<String> value = new LinkedHashSet<String>(); 
			value.clear();
			value = entry.getValue();
			
			//each split sentence in an line.
			for(String sentence : value){
				
				/*
				 * plant NER start per sentence
				 */
				Ptemp_chunk_result.clear();
				Pchunk_result.clear();
				Ptemp_chunk_result = Pchunk(P_dictionaryChunkerTF, sentence.toLowerCase(), "BROMFED-DM", "9");
				Pchunk_result = filtering(Ptemp_chunk_result);
				
				
				/*
				 * chemical NER start per sentence
				 */
				Cchunk_result.clear();
				for (Mention mention : tagger.tag(sentence)) {
					  Cchunk_result.add(mention.getStart()+"\t"+mention.getEnd()+"\t"+mention.getText()+"\t"+mention.getCAS()+"|"+mention.getCHEB()+"|"+mention.getMESH());
				}
				
				if(Pchunk_result.size() > 0 & Cchunk_result.size() > 0){
					for(String annotatedplants : Pchunk_result){
						String[] plant_contents = annotatedplants.split("\t");
						String plantStartEnd = plant_contents[1]+"_"+plant_contents[2];
						String plantName = plant_contents[0].toLowerCase();
						String plantID = plant_contents[3];
						for(String annotatedchemicals : Cchunk_result){
							String[] chemical_contents = annotatedchemicals.split("\t");
							String chemicalStartEnd = chemical_contents[0]+"_"+chemical_contents[1];
							String chemicalName = chemical_contents[2].toLowerCase();
							String chemicalID = chemical_contents[3];
							sentence_units.add(key+"\t"+sentence+"\t"+plantName+"\t"+plantID+"\t"+plantStartEnd+"\t"+chemicalName+"\t"+chemicalID+"\t"+chemicalStartEnd);
							cooccurrence.write(key+"\t"+sentence+"\t"+plantName+"\t"+plantStartEnd+"\t"+chemicalName+"\t"+chemicalStartEnd);
							cooccurrence.newLine();
						}
					}
				}
			}
		}
		cooccurrence.close();
		return sentence_units;
    }
	
	
	/*
	 * Filtering annotated plant names [e.g., there are two annotated entities ("cold" and "common cold"), 
	 * we choose "common cold" through this filtering step]).
	 */
	 static LinkedHashSet<String> filtering(LinkedHashSet<String> Ptemp_chunk_result){
	    	LinkedHashSet<String> new_chunk_result = new LinkedHashSet<String>();
	    	LinkedHashSet<String> new_new_chunk_result = new LinkedHashSet<String>();
	    	
	    	for(String h1 : Ptemp_chunk_result){
	    		String[] contents = h1.split("\t");
	    		String phrase = contents[0];
	    		String start = contents[1];
	    		String end = contents[2];
	    		String id = contents[3];
	    		String saveEnd = "";
	    		int counter = 0;
	    		for(String h2 : Ptemp_chunk_result){
	    			String[] contents_new = h2.split("\t");
	    			if(start.toLowerCase().trim().equals(contents_new[1].toLowerCase().trim())){
		    			saveEnd = saveEnd + contents_new[2] + "\t";
		    			++counter;
		    		}
	    		}
	    		if(counter == 0){
	    			int counter_new = 0;
	    			for(String h3 : Ptemp_chunk_result){
	    				String[] contents_new = h3.split("\t");
	    				if(end.toLowerCase().trim().equals(contents_new[2].toLowerCase().trim())){
	    					if(Integer.valueOf(start.toLowerCase().trim()) > Integer.valueOf(contents_new[1].toLowerCase().trim())){
	    						++counter_new;
	    					}
	    				}
	    			}
	    			if(counter_new == 0){
	    				new_chunk_result.add(h1);
	    			}
	    			else{
	    				continue;
	    			}
	    		}
	    		else{
	    			String[] End_contents = saveEnd.split("\t");
	    			String newEnd = "";
	    			for(String n : End_contents){
	    				newEnd = n;
	    			}
	    			int counter_new_new = 0;
	    			for(String h3 : Ptemp_chunk_result){
	    				String[] contents_new = h3.split("\t");
	    				if(newEnd.toLowerCase().trim().equals(contents_new[2].toLowerCase().trim())){
	    					if(Integer.valueOf(start.toLowerCase().trim()) > Integer.valueOf(contents_new[1].toLowerCase().trim())){
	    						++counter_new_new;
	    					}
	    				}
	    			}
	    			if(counter_new_new == 0){
	    				for(String h3 : Ptemp_chunk_result){
	    					String[] contents_new = h3.split("\t");
	    					if(newEnd.toLowerCase().trim().equals(contents_new[2].toLowerCase().trim())){
	    						if(start.toLowerCase().trim().equals(contents_new[1].toLowerCase().trim())){
	    							new_chunk_result.add(h3);
	    						}
	    					}
	    				}
	    			}
	    			else{
	    				continue;
	    			}
	    		}
	    	}
	    	for(String str : new_chunk_result){
	    		String[] contents = str.split("\t");
	    		int counter = 0;
	    		
	    		for(String str_new : new_chunk_result){
	    			String[] contents2 = str_new.split("\t");
	    			if(Integer.valueOf(contents[1]) > Integer.valueOf(contents2[1])){
	    				if(Integer.valueOf(contents[2]) < Integer.valueOf(contents2[2])){
	    					++counter;
	    				}
	    			}
	    		}
	    		if(counter == 0){
	    			new_new_chunk_result.add(str);
	    		}
	    		else{
	    			continue;
	    		}
	    	}
	    	return new_new_chunk_result;
	 }
	 
	 
	 /*
	  * Remove stopwords. 
	  */
	 static LinkedHashSet<String> Pchunk(ExactDictionaryChunker chunker, String text, String option1, String option2) throws IOException {
	    	LinkedHashSet<String> result = new LinkedHashSet<String>();
	    	result.clear();
	    	
	        Chunking chunking = chunker.chunk(text);
	        for (Chunk chunk : chunking.chunkSet()) {
	            int start = chunk.start();
	            int end = chunk.end();
	            String id = chunk.type();
	            double score = chunk.score();
	            String phrase = text.substring(start,end);
	            
	            
	            //Remove Named entities whose length is less than 3.
	            if(phrase.length() < 4){
	            	continue;
	            }
	    		
	            result.add(phrase+"\t"+start+"\t"+end+"\t"+id);
	            
	        }
	        return result;
	    }
}
