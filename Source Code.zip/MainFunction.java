
import java.io.BufferedReader;
import java.io.BufferedWriter;
import java.io.File;
import java.io.FileReader;
import java.io.FileWriter;
import java.io.IOException;
import java.util.LinkedHashMap;
import java.util.LinkedHashSet;
import java.util.LinkedList;
import java.util.Map.Entry;

import com.aliasi.dict.DictionaryEntry;
import com.aliasi.dict.ExactDictionaryChunker;
import com.aliasi.dict.MapDictionary;
import com.aliasi.tokenizer.IndoEuropeanTokenizerFactory;

import NER_Module.EntityDetection;
import Rule_based_module.Apposition_Rule;
import Rule_based_module.CompoundNounTrigger_Rule;
import Rule_based_module.CopulaTrigger_Rule;
import Rule_based_module.PrepTrigger_Rule;
import Rule_based_module.RelativeTrigger_Rule;
import Rule_based_module.VerbalTriger_Rule;
import Splitter.SentenceSplitter;
import de.berlin.hu.chemspot.ChemSpot;
import de.berlin.hu.chemspot.ChemSpotFactory;
import edu.stanford.nlp.parser.lexparser.LexicalizedParser;
import edu.stanford.nlp.trees.Tree;

public class MainFunction {
	static final double CHUNK_SCORE = 1.0;
	static Tree subtree;
	static int countLine = 0;
	static ChemSpot tagger = ChemSpotFactory.createChemSpot(
			"C:\\Jar_Library\\chemspot-2.0\\dict.zip",
			"C:\\Jar_Library\\chemspot-2.0\\ids.zip",
			"C:\\Jar_Library\\chemspot-2.0\\multiclass.bin");
	
	public static void main(String[] args) throws IOException{
		/*
		 * 
		 * <Main function>
		 * You need to set the path of .txt file containing co-occurrence sentences.
		 * To get the .txt file, you should run ***.java code, first.
		 *
		 */
		
		//Set the input path where abstracts are stored.
		String abstractsFolderPath = "C:/Users/choi/Desktop/cwj/InputFile";
		File folder = new File(abstractsFolderPath);
		File[] listOfFiles = folder.listFiles();
		//Set the output path where predicted results will be stored.
		BufferedWriter out = new BufferedWriter(new FileWriter("C:/Users/choi/Desktop/cwj/Predicted_Plant_Chemical_Relationships.txt", true));
		//Plant dictionary
		String PlantDictionary = "C:/Users/choi/Desktop/cwj/Plant_Dictionary.txt";
		
		/*
		 * 
		 * 	Plant Dictionary load
		 * 
		 */
		MapDictionary<String> Plant_dictionary = new MapDictionary<String>();
    	File PDicfile = new File(PlantDictionary);
		BufferedReader PDic_br = new BufferedReader(new FileReader(PDicfile));
		String Pline = null;
		
		System.out.println("Dictionary loading....");
		while((Pline = PDic_br.readLine()) != null){
			String[] contents = Pline.split("\t");
			String ID = contents[0];
			String PlantName = contents[1];
			
			Plant_dictionary.addEntry(new DictionaryEntry<String>(PlantName,ID,CHUNK_SCORE));
			
		}
		System.out.println("Plant Dictionary is sucessfully loaded");
		
    	ExactDictionaryChunker P_dictionaryChunkerTF = new ExactDictionaryChunker(Plant_dictionary, IndoEuropeanTokenizerFactory.INSTANCE, true,false);
		
		
		/*
		 * 
		 * Sentence splitter
		 * 
		 */
		for (File texts : listOfFiles) {
		    if (texts.isFile()) {
		    	System.out.println("Current File : " + texts.getName());
				LinkedHashMap<String, LinkedHashSet<String>> splitSentence_for_each_line = new LinkedHashMap<String, LinkedHashSet<String>>();
				SentenceSplitter splitter = new SentenceSplitter();
				splitSentence_for_each_line = splitter.Splitter(texts);
				
				for(Entry<String,LinkedHashSet<String>> entry : splitSentence_for_each_line.entrySet()){ //split �� sentence ���� annotated phenotype ���.
					String key = entry.getKey();
					LinkedHashSet<String> value = new LinkedHashSet<String>(); 
					value.clear();
					value = entry.getValue();
					for(String h : value){
						System.out.println(key +"\t"+ h);
					}
				}
				
				
				
				/*
				 * 
				 * Start NER module for plants and chemicals
				 * 
				 */
				LinkedHashSet<String> sentence_units = new LinkedHashSet<String>();
				EntityDetection plant_detector = new EntityDetection();
				sentence_units = plant_detector.NodeDectector(splitSentence_for_each_line, P_dictionaryChunkerTF, tagger);	
				
				
				/*
				 * 
				 * Start Rule-based module
				 * 
				 */
				//Loading Stanford Parser
				LexicalizedParser lp = LexicalizedParser.loadModel("edu/stanford/nlp/models/lexparser/englishPCFG.ser.gz");
				
				//Initialize rule instances
				PrepTrigger_Rule prep = new PrepTrigger_Rule();
				VerbalTriger_Rule verbal = new VerbalTriger_Rule();
				RelativeTrigger_Rule relative = new RelativeTrigger_Rule();
				Apposition_Rule apposition = new Apposition_Rule();
				CopulaTrigger_Rule copula = new CopulaTrigger_Rule();
				CompoundNounTrigger_Rule compound = new CompoundNounTrigger_Rule();		
				
				//initialize LinkedHashSet variables to store predicted results.
				LinkedHashSet<String> PredictedRelationships = new LinkedHashSet<String>();
				LinkedHashSet<String> temp = new LinkedHashSet<String>();
				
				for(String su : sentence_units){
					String[] contents = su.split("\t");
					String pmid = contents[0];
					String sentence = contents[1].toLowerCase().trim();
					String plantName = contents[2].toLowerCase().trim();
					String plantID = contents[3];
					String plantStartEnd = contents[4];
					String chemicalName = contents[5].toLowerCase().trim();
					String chemicalID = contents[6];
					String chemicalStartEnd = contents[7];
					
					++countLine; //Line counter
				    
					LinkedHashSet<String> plant = new LinkedHashSet<String>();
					LinkedHashSet<String> chemical = new LinkedHashSet<String>();
					plant.clear();
					chemical.clear();
					
					plant.add(plantName+"_"+plantID);
					chemical.add(chemicalName+"_"+chemicalID);
					
					
					
					/*
					 * Apply rule-based model to extracted co-occurrence sentences.  
					 */
					
					
					temp = verbal.VerbalTrigger(lp, sentence, pmid, plant, chemical, plantStartEnd, chemicalStartEnd);
					for(String s : temp){
						PredictedRelationships.add(s);
					}
					temp.clear();
					
					temp = prep.PrepTrigger(lp, sentence, pmid, plant, chemical, plantStartEnd, chemicalStartEnd);
					for(String s : temp){
						PredictedRelationships.add(s);
					}
					temp.clear();
					
					temp = relative.RelativeTrigger(lp, sentence,pmid, plant, chemical, plantStartEnd, chemicalStartEnd);
					for(String s : temp){
						PredictedRelationships.add(s);
					}
					temp.clear();
					
					temp = apposition.AppositionTrigger(lp, sentence,pmid, plant, chemical, plantStartEnd, chemicalStartEnd);
					for(String s : temp){
						PredictedRelationships.add(s);
					}
					temp.clear();
					
					temp = copula.HyponymTrigger(lp, sentence, pmid, plant, chemical, plantStartEnd, chemicalStartEnd);
					for(String s : temp){
						PredictedRelationships.add(s);
					}
					temp.clear();
					
					temp = compound.CompoundNounTrigger(lp, sentence, pmid, plant,chemical, plantStartEnd, chemicalStartEnd);
					for(String s : temp){
						PredictedRelationships.add(s);
					}
					temp.clear();
					
					int counter = 0; 
					//Retrieve predicted results (plant-chemical relationships).
					//POSITIVES
					for(String s : PredictedRelationships){
						++counter;
						String[] split = s.split("\t");
						String plantName_ID = split[0].substring(0, split[0].length()-1);;
						String chemicalName_ID = split[1].substring(0, split[1].length()-1);
						String triggerterm = split[2];
						String predictedsentence = split[3];
						String predictedPMID = split[4];
						String plantStart_End = split[5];
						String chemicalStart_End = split[6];
						
						System.out.println(plantName_ID+"\t"+plantStart_End+"\t"+triggerterm+"\t"+chemicalName_ID+"\t"+chemicalStart_End+"\t"+predictedsentence+"\t"+predictedPMID+"\t"+"POS");
						out.write(plantName_ID+"\t"+plantStart_End+"\t"+triggerterm+"\t"+chemicalName_ID+"\t"+chemicalStart_End+"\t"+predictedsentence+"\t"+predictedPMID+"\t"+"POS");
						out.newLine();
						break;
					}
					//NEGATIVES
					if(counter == 0){
						out.write(plantName+"_"+plantID+"\t"+plantStartEnd+"\t"+"NA"+"\t"+chemicalName+"_"+chemicalID+"\t"+chemicalStartEnd+"\t"+sentence+"\t"+pmid+"\t"+"NEG");
						out.newLine();
					}
					PredictedRelationships.clear();
				}
		    }
		}
		out.close();
	}
}
