package Rule_based_module;


import java.io.IOException;
import java.io.Reader;
import java.io.StringReader;
import java.util.ArrayList;
import java.util.Collection;
import java.util.Iterator;
import java.util.LinkedHashSet;
import java.util.List;
import java.util.SortedSet;
import java.util.TreeSet;

import edu.stanford.nlp.ling.HasWord;
import edu.stanford.nlp.parser.lexparser.LexicalizedParser;
import edu.stanford.nlp.process.DocumentPreprocessor;
import edu.stanford.nlp.trees.GrammaticalStructure;
import edu.stanford.nlp.trees.GrammaticalStructureFactory;
import edu.stanford.nlp.trees.PennTreebankLanguagePack;
import edu.stanford.nlp.trees.Tree;
import edu.stanford.nlp.trees.TreeGraphNode;
import edu.stanford.nlp.trees.TreebankLanguagePack;
import edu.stanford.nlp.trees.TypedDependency;
import edu.stanford.nlp.trees.WordStemmer;

public class CopulaTrigger_Rule {
	public static LinkedHashSet<String> HyponymTrigger(LexicalizedParser lp, String line, String PMID,LinkedHashSet<String> plant, LinkedHashSet<String> chemical, String plantStartEnd, String chemicalStartEnd) throws IOException {
		LinkedHashSet<String> CorpulaResult = new LinkedHashSet<String>();
		int sentenceCounter = 0;
		TreebankLanguagePack tlp = new PennTreebankLanguagePack();
		GrammaticalStructureFactory gsf = tlp.grammaticalStructureFactory();
		WordStemmer ls = new WordStemmer();
		Reader reader = new StringReader(line);
		DocumentPreprocessor dp = new DocumentPreprocessor(reader);
		
		Iterator<List<HasWord>> it = dp.iterator();
		List<HasWord> sentence = null;
		while (it.hasNext()) {
			sentence = it.next();
		}
		++sentenceCounter;
		LinkedHashSet<String> hs = new LinkedHashSet<String>();
		Tree parse = lp.apply(sentence);
		
		List<Tree> phraseList=new ArrayList<Tree>();
		 
		
		GrammaticalStructure gs = gsf.newGrammaticalStructure(parse);
		Collection tdl = gs.typedDependencies();
		
		
		int i = 0;
		int arraySize = 0;
		
		
		/*
		 * Calculate array size
		 */
		for( Iterator<TypedDependency> iter = tdl.iterator(); iter.hasNext(); ) {
			TypedDependency var = iter.next();
			TreeGraphNode dep = var.dep();
			TreeGraphNode gov = var.gov();
			// All useful information for a node in the tree
			String dependencyType = var.reln().getShortName();
			int Token_ID = var.dep().index();
			int Parent_ID = var.gov().index();
			String token = var.dep().pennString();
			token = token.substring(0,token.length()-2); 
			
			if(i == tdl.size()-1){
				arraySize = Token_ID+1;
			}
			++i;
		}
		String[][] names = new String[arraySize][4];
		for(int j = 0 ; j <arraySize ; j++){
			for(int k = 0 ; k < 4 ; k++){
				names[j][k] = "";
			}
		}
		int c = 0;
		int BeginofToken = 0;
		int EndofToken = 0;
		
		/*
		 * 
		 * Check if each parse tree of the sentence has the same structure of copula trigger rule.
		 * 
		 */
		for( Iterator<TypedDependency> iter = tdl.iterator(); iter.hasNext(); ) {
			TypedDependency var = iter.next();
			
			TreeGraphNode dep = var.dep();
			TreeGraphNode gov = var.gov();
			// All useful information for a node in the tree
			String dependencyType = var.reln().getShortName();
			int Token_ID = var.dep().index();
			int Parent_ID = var.gov().index();
			String token = var.dep().pennString();
			token = token.substring(0,token.length()-2);
			
			names[Token_ID][0] = token;
			names[Token_ID][1] = String.valueOf(Token_ID);
			names[Token_ID][2] = String.valueOf(Parent_ID);
			names[Token_ID][3] = dependencyType;
			
			ArrayList<Tree>temp = new ArrayList<Tree>();
			
			if(c==0){
				BeginofToken = Token_ID;
			}
			++c;
		}
		
		EndofToken = arraySize -1; 
		
		for(int q = 1 ; q < arraySize ; q++){
			int start = 0;
			int end = 0;
			String LeftHand = "";
			String RightHand = "";
			if(names[q][3].equals("cop")){
				int NodeIDForRightHand = Integer.valueOf(names[q][1]);
				int NodeParentIDForRightHand = Integer.valueOf(names[q][2]);
				int NodeID = Integer.valueOf(names[q][1]);
				int NodeParentID = Integer.valueOf(names[q][2]);
				SortedSet LeftHandset = new TreeSet();
				for(int k = NodeID-1 ; k > 0 ; k--){
					if(names[k][2].equals("")){
						continue;
					}
					if(Integer.valueOf(names[k][2]) == NodeParentID){
						NodeID = Integer.valueOf(names[k][1]);
						LeftHandset.add(Integer.valueOf(names[k][1]));
					}else if(Integer.valueOf(names[k][2]) == NodeID){
						NodeID = Integer.valueOf(names[k][1]);
						NodeParentID = Integer.valueOf(names[k][2]);
						LeftHandset.add(Integer.valueOf(names[k][1]));
					}
				}
				if(LeftHandset.size() > 0){
					start = Integer.valueOf(String.valueOf(LeftHandset.first()));
					end = Integer.valueOf(String.valueOf(LeftHandset.last()));
					for(int Start = start ; Start <= end ; Start++){
						LeftHand += names[Start][0] + " ";
					}
				}
				
				
				/*
				 * RightHand 
				 */
				int FinishCount = 0;
				SortedSet RightHandset = new TreeSet();
				while(true){
					
					int No = 0;
					for(int p = NodeIDForRightHand ; p < arraySize ; p++){
						if(names[p][2].equals("")){
							continue;
						}
						if(Integer.valueOf(names[p][2]) == NodeParentIDForRightHand){
							if(RightHandset.contains(Integer.valueOf(names[p][1]))){
								++FinishCount;
							}else{
								RightHandset.add(Integer.valueOf(names[p][1]));
							}
							++No;
						}
						
						else if(NodeParentIDForRightHand == arraySize-1){
							++FinishCount;
						}
					}
					//Decide max value
					NodeParentIDForRightHand = Integer.valueOf(String.valueOf(RightHandset.last()));
					
					if(FinishCount > 0){
						break;
					}
					
					if(No == 0){
						break;
					}
				}
				//Extract Noun phrases 
				if(RightHandset.size() > 0){
					start = Integer.valueOf(String.valueOf(RightHandset.first())) + 1;
					end = Integer.valueOf(String.valueOf(RightHandset.last()));
					
					for(int Start = start ; Start <= end ; Start++){
						RightHand += names[Start][0] + " ";
					}
				}
				
				/*
				 * Predicted results as follows: <plant is a source of chemical>
				 */
				int p_count = 0;
				int c_count = 0;
				String plantMention = "";
				String ChemicalMention = "";
				
				
				for(String s : chemical){
					String[] chemical_split = s.split("_");
					if(LeftHand.toLowerCase().contains(chemical_split[0].toLowerCase())){
						ChemicalMention += s + "|";
						++c_count;
					}
				}
				for(String s : plant){
					String[] plant_split = s.split("_");
					if(RightHand.toLowerCase().contains(plant_split[0].toLowerCase())){
						plantMention += s + "|";
						++p_count;
					}
				}
				
				if(p_count > 0 && c_count > 0){
					CorpulaResult.add(plantMention + "\t" + ChemicalMention + "\t" + names[q][0]+"(copula)" + "\t" + line +"\t" + PMID + "\t"+ plantStartEnd + "\t" + chemicalStartEnd);
					break;
				}
				
				/*
				 * Predicted results as follows: <chemical is a component of plant>
				 */
				p_count = 0;
				c_count = 0;
				plantMention = "";
				ChemicalMention = "";
				
				
				for(String s : chemical){
					String[] chemical_split = s.split("_");
					if(RightHand.toLowerCase().contains(chemical_split[0].toLowerCase())){
						ChemicalMention += s + "|";
						++c_count;
					}
				}
				for(String s : plant){
					String[] plant_split = s.split("_");
					if(LeftHand.toLowerCase().contains(plant_split[0].toLowerCase())){
						plantMention += s + "|";
						++p_count;
					}
				}
				
				if(p_count > 0 && c_count > 0){
					CorpulaResult.add(plantMention + "\t" + ChemicalMention + "\t" + names[q][0]+"(copula)" + "\t" + line +"\t" + PMID + "\t"+ plantStartEnd + "\t" + chemicalStartEnd);
					break;
				}
			}
		}
		return CorpulaResult;
	}
}
