package Rule_based_module;

import java.io.IOException;
import java.io.Reader;
import java.io.StringReader;
import java.util.ArrayList;
import java.util.Arrays;
import java.util.Collection;
import java.util.Iterator;
import java.util.LinkedHashSet;
import java.util.List;
import java.util.SortedSet;
import java.util.TreeSet;

import edu.stanford.nlp.ling.HasWord;
import edu.stanford.nlp.parser.lexparser.LexicalizedParser;
import edu.stanford.nlp.process.DocumentPreprocessor;
import edu.stanford.nlp.trees.GrammaticalStructure;
import edu.stanford.nlp.trees.GrammaticalStructureFactory;
import edu.stanford.nlp.trees.PennTreebankLanguagePack;
import edu.stanford.nlp.trees.Tree;
import edu.stanford.nlp.trees.TreeGraphNode;
import edu.stanford.nlp.trees.TreebankLanguagePack;
import edu.stanford.nlp.trees.TypedDependency;
import edu.stanford.nlp.trees.WordStemmer;

public class RelativeTrigger_Rule {
	static final List<String> pastPart = Arrays.asList(
			
			//Chemical extracted from plant
			"contained",
			"involved",
			"incorporated",
			"possessed",
			"encompassed",
			"subsumed",
			"comprised",
			"embodied",
			"embraced",
			"included",
			"covered",
			"composed",
			"produced",
			"originated",
			"derived",
			"accumulated",
			"released",
			"isolated",
			"extracted",
			"separated",
			"detached",
			"split",
			"segregated",
			"obtained",
			"found",
			"gained",
			"discovered",
			"uncovered",
			"identified"
			);
	static final List<String> ingPart = Arrays.asList(
			"containing",
			"involving",
			"incorporating",
			"possessing",
			"encompassing",
			"subsuming",
			"comprising",
			"embracing",
			"including",
			"covering",
			"composing",
			"embodying",
			"producing",
			"originating",
			"deriving",
			"accumulating",
			"releasing",
			"having",
			"consisting"
			);
	
	public static LinkedHashSet<String> RelativeTrigger(LexicalizedParser lp, String line,String PMID, LinkedHashSet<String> plant, LinkedHashSet<String> chemical, String plantStartEnd, String chemicalStartEnd) throws IOException {
		
		LinkedHashSet<String> RelativeResult = new LinkedHashSet<String>();
		int sentenceCounter = 0;
		//System.out.println("---------------RelativeTrigger-----------------");
		TreebankLanguagePack tlp = new PennTreebankLanguagePack();
		GrammaticalStructureFactory gsf = tlp.grammaticalStructureFactory();
		WordStemmer ls = new WordStemmer();
		Reader reader = new StringReader(line);
		DocumentPreprocessor dp = new DocumentPreprocessor(reader);
		
		Iterator<List<HasWord>> it = dp.iterator();
		List<HasWord> sentence = null;
		while (it.hasNext()) {
			sentence = it.next();
		}
		//System.out.println("==============================Start===================================");;
		++sentenceCounter;
		LinkedHashSet<String> hs = new LinkedHashSet<String>();
		Tree parse = lp.apply(sentence);
		//System.out.println(sentence);
		
		List<Tree> phraseList=new ArrayList<Tree>();
		 
		
		GrammaticalStructure gs = gsf.newGrammaticalStructure(parse);
		Collection tdl = gs.typedDependencies();
		
		
		int i = 0;
		int arraySize = 0;
		
		
		/*
		 * calcaulate array size
		 */
		for( Iterator<TypedDependency> iter = tdl.iterator(); iter.hasNext(); ) {
			TypedDependency var = iter.next();
			TreeGraphNode dep = var.dep();
			TreeGraphNode gov = var.gov();
			// All useful information for a node in the tree
			String dependencyType = var.reln().getShortName();
			int Token_ID = var.dep().index();
			int Parent_ID = var.gov().index();
			String token = var.dep().pennString();
			token = token.substring(0,token.length()-2); 
			
			if(i == tdl.size()-1){
				arraySize = Token_ID+1;
			}
			++i;
		}
		String[][] names = new String[arraySize][4];
		for(int j = 0 ; j <arraySize ; j++){
			for(int k = 0 ; k < 4 ; k++){
				names[j][k] = "";
			}
		}
		int c = 0;
		int BeginofToken = 0;
		int EndofToken = 0;
		
		for( Iterator<TypedDependency> iter = tdl.iterator(); iter.hasNext(); ) {
			TypedDependency var = iter.next();
			
			TreeGraphNode dep = var.dep();
			TreeGraphNode gov = var.gov();
			// All useful information for a node in the tree
			String dependencyType = var.reln().getShortName();
			int Token_ID = var.dep().index();
			int Parent_ID = var.gov().index();
			String token = var.dep().pennString();
			token = token.substring(0,token.length()-2);
			
			names[Token_ID][0] = token;
			names[Token_ID][1] = String.valueOf(Token_ID);
			names[Token_ID][2] = String.valueOf(Parent_ID);
			names[Token_ID][3] = dependencyType;
			
			ArrayList<Tree>temp = new ArrayList<Tree>();
			
			if(c==0){
				BeginofToken = Token_ID;
			}
			++c;
		}
		
		EndofToken = arraySize -1; 
		
		
		for(int q = 1 ; q < arraySize ; q++){
			if(names[q][3].equals("partmod")){
				int start = 0;
				int end = 0;
				String LeftHand = "";
				String RightHand = "";
				int NodeParentID = Integer.valueOf(names[q][2]);
				int NodeID = Integer.valueOf(names[q][1]);
				String Trigger = names[q][0];
				
				SortedSet LeftHandset = new TreeSet();
				LeftHandset.add(NodeID);
				for(int k = NodeID-1 ; k > 0 ; k--){
					if(names[k][2].equals("")){
						continue;
					}
					
					if(Integer.valueOf(names[k][1]).equals(NodeParentID)){
						LeftHandset.add(Integer.valueOf(names[k][1]));
					}
					else if(Integer.valueOf(names[k][2]).equals(NodeParentID)){
						LeftHandset.add(Integer.valueOf(names[k][1]));
					}
				}
				
				
				int min = Integer.valueOf(names[q][1]);
				int max = Integer.valueOf(names[q][1]);
				int FinishCount = 0;
				SortedSet RightHandset = new TreeSet();
				RightHandset.add(Integer.valueOf(names[q][1]));
				while(true){
					int No = 0;
					for(int k = 1 ; k < arraySize ; k++){
						if(names[k][2].equals("")){
							continue;
						}
						if(Integer.valueOf(names[k][2]) == max){
							if(RightHandset.contains(Integer.valueOf(names[k][1]))){
								++FinishCount;
							}else{
								RightHandset.add(Integer.valueOf(names[k][1]));
							}
							++No;
						}
						
						else if(max == arraySize-1){
							++FinishCount;
						}
					}
					//decide max value
					max = Integer.valueOf(String.valueOf(RightHandset.last()));
					if(FinishCount > 0){
						break;
					}
					if(No == 0){
						break;
					}
				}
				//extract noun phrases
				//System.out.println("current set : " + set);
				if(RightHandset.size() > 0){
					start = Integer.valueOf(String.valueOf(RightHandset.first())) +1;
					end = Integer.valueOf(String.valueOf(RightHandset.last()));
					//RightHand = "";
					for(int Start = start ; Start <= end ; Start++){
						RightHand += names[Start][0] + " ";
					}
				}
				
				if(LeftHandset.size() > 0){
					start = Integer.valueOf(String.valueOf(LeftHandset.first()));
					end = Integer.valueOf(String.valueOf(LeftHandset.last())) - 1;
					//String LeftHand = "";
					for(int Start = start ; Start <= end ; Start++){
						LeftHand += names[Start][0] + " ";
					}
				}
				
				
				//++nsubjCount;
				//System.out.println("###########");
				//System.out.println(LeftHand);
				//System.out.println(Trigger);
				//System.out.println(RightHand);
				
				
				
				for(String trigger : pastPart){
					if(Trigger.toLowerCase().equals(trigger.toLowerCase())){
						int t_count = 0;
						int p_count = 0;
						int c_count = 0;
						String plantMention = "";
						String ChemicalMention = "";
						
						for(String s : plant){
							String[] plant_split = s.split("_");
							if(RightHand.toLowerCase().contains(plant_split[0].toLowerCase())){
								plantMention += s + "|";
								++p_count;
							}
						}
						for(String s : chemical){
							String[] chemical_split = s.split("_");
							if(LeftHand.toLowerCase().contains(chemical_split[0].toLowerCase())){
								ChemicalMention += s + "|";
								++c_count;
							}
						}
						
						if(p_count > 0 && c_count > 0){
							//System.out.println(plantMention+"_"+ChemicalMention+"_"+Trigger);
							RelativeResult.add(plantMention + "\t" + ChemicalMention + "\t" + Trigger + "\t" + line +"\t"+ PMID + "\t"+ plantStartEnd + "\t" + chemicalStartEnd);
							break;
						}
						
					}
				}
				
				for(String trigger : ingPart){
					if(Trigger.toLowerCase().equals(trigger.toLowerCase())){
						int t_count = 0;
						int p_count = 0;
						int c_count = 0;
						String plantMention = "";
						String ChemicalMention = "";
						
						for(String s : plant){
							String[] plant_split = s.split("_");
							if(LeftHand.toLowerCase().contains(plant_split[0].toLowerCase())){
								plantMention += s + "|";
								++p_count;
							}
						}
						for(String s : chemical){
							String[] chemical_split = s.split("_");
							if(RightHand.toLowerCase().contains(chemical_split[0].toLowerCase())){
								ChemicalMention += s + "|";
								++c_count;
							}
						}
						
						if(p_count > 0 && c_count > 0){
							//System.out.println(plantMention+"_"+ChemicalMention+"_"+Trigger);
							RelativeResult.add(plantMention + "\t" + ChemicalMention + "\t" + Trigger + "\t" + line +"\t"+ PMID + "\t"+ plantStartEnd + "\t" + chemicalStartEnd);
							break;
						}
						
					}
				}
				
			
				
				
			}
			else if(names[q][3].equals("ccomp")){
				int start = 0;
				int end = 0;
				String LeftHand = "";
				String RightHand = "";
				int NodeParentID = Integer.valueOf(names[q][2]);
				int NodeID = Integer.valueOf(names[q][1]);
				String Trigger = names[q][0];
				
				SortedSet LeftHandset = new TreeSet();
				LeftHandset.add(NodeID);
				for(int k = NodeID-1 ; k > 0 ; k--){
					if(names[k][2].equals("")){
						continue;
					}
					if(Integer.valueOf(names[k][1]).equals(NodeParentID)){
						LeftHandset.add(Integer.valueOf(names[k][1]));
					}
					else if(Integer.valueOf(names[k][2]).equals(NodeParentID)){
						LeftHandset.add(Integer.valueOf(names[k][1]));
					}
				}
				
				
				int min = Integer.valueOf(names[q][1]);
				int max = Integer.valueOf(names[q][1]);
				int FinishCount = 0;
				SortedSet RightHandset = new TreeSet();
				RightHandset.add(Integer.valueOf(names[q][1]));
				while(true){
					int No = 0;
					for(int k = 1 ; k < arraySize ; k++){
						if(names[k][2].equals("")){
							continue;
						}
						if(Integer.valueOf(names[k][2]) == max){
							if(RightHandset.contains(Integer.valueOf(names[k][1]))){
								++FinishCount;
							}else{
								RightHandset.add(Integer.valueOf(names[k][1]));
							}
							++No;
						}
						
						else if(max == arraySize-1){
							++FinishCount;
						}
					}
					//decide max value
					max = Integer.valueOf(String.valueOf(RightHandset.last()));
					if(FinishCount > 0){
						break;
					}
					if(No == 0){
						break;
					}
				}
				//extract noun phrases
				if(RightHandset.size() > 0  && LeftHandset.size() > 0){
					start = Integer.valueOf(String.valueOf(RightHandset.first())) +1;
					end = Integer.valueOf(String.valueOf(RightHandset.last()));
					for(int Start = start ; Start <= end ; Start++){
						RightHand += names[Start][0] + " ";
					}
				
				
					start = Integer.valueOf(String.valueOf(LeftHandset.first()));
					end = Integer.valueOf(String.valueOf(LeftHandset.last())) - 1;
					for(int Start = start ; Start <= end ; Start++){
						LeftHand += names[Start][0] + " ";
					}
				}
				
				for(String trigger : pastPart){
					if(Trigger.toLowerCase().equals(trigger.toLowerCase())){
						int t_count = 0;
						int p_count = 0;
						int c_count = 0;
						String plantMention = "";
						String ChemicalMention = "";
						
						for(String s : plant){
							String[] plant_split = s.split("_");
							if(RightHand.toLowerCase().contains(plant_split[0].toLowerCase())){
								plantMention += s + "|";
								++p_count;
							}
						}
						for(String s : chemical){
							String[] chemical_split = s.split("_");
							if(LeftHand.toLowerCase().contains(chemical_split[0].toLowerCase())){
								ChemicalMention += s + "|";
								++c_count;
							}
						}
						if(p_count > 0 && c_count > 0){
							RelativeResult.add(plantMention + "\t" + ChemicalMention + "\t" + Trigger + "\t" + line +"\t"+ PMID + "\t"+ plantStartEnd + "\t" + chemicalStartEnd);
							break;
						}
					}
				}
				
				for(String trigger : ingPart){
					if(Trigger.toLowerCase().equals(trigger.toLowerCase())){
						int t_count = 0;
						int p_count = 0;
						int c_count = 0;
						String plantMention = "";
						String ChemicalMention = "";
						
						for(String s : plant){
							String[] plant_split = s.split("_");
							if(LeftHand.toLowerCase().contains(plant_split[0].toLowerCase())){
								plantMention += s + "|";
								++p_count;
							}
						}
						for(String s : chemical){
							String[] chemical_split = s.split("_");
							if(RightHand.toLowerCase().contains(chemical_split[0].toLowerCase())){
								ChemicalMention += s + "|";
								++c_count;
							}
						}
						
						if(p_count > 0 && c_count > 0){
							RelativeResult.add(plantMention + "\t" + ChemicalMention + "\t" + Trigger + "\t" + line +"\t"+ PMID + "\t"+ plantStartEnd + "\t" + chemicalStartEnd);
							break;
						}
						
					}
				}
			}
		}
		return RelativeResult;
	}
}
