package Rule_based_module;

import java.io.BufferedWriter;
import java.io.FileWriter;
import java.io.IOException;
import java.io.Reader;
import java.io.StringReader;
import java.util.ArrayList;
import java.util.Collection;
import java.util.Iterator;
import java.util.LinkedHashSet;
import java.util.LinkedList;
import java.util.List;
import java.util.SortedSet;
import java.util.TreeSet;

import edu.stanford.nlp.ling.HasWord;
import edu.stanford.nlp.parser.lexparser.LexicalizedParser;
import edu.stanford.nlp.process.DocumentPreprocessor;
import edu.stanford.nlp.trees.GrammaticalStructure;
import edu.stanford.nlp.trees.GrammaticalStructureFactory;
import edu.stanford.nlp.trees.PennTreebankLanguagePack;
import edu.stanford.nlp.trees.Tree;
import edu.stanford.nlp.trees.TreeGraphNode;
import edu.stanford.nlp.trees.TreebankLanguagePack;
import edu.stanford.nlp.trees.TypedDependency;
import edu.stanford.nlp.trees.WordStemmer;

public class PrepTrigger_Rule {
	public static LinkedHashSet<String> PrepTrigger(LexicalizedParser lp, String line,String PMID, LinkedHashSet<String> plant, LinkedHashSet<String> chemical, String plantStartEnd, String chemicalStartEnd) throws IOException {
			LinkedHashSet<String> PrepResult = new LinkedHashSet<String>();
			int sentenceCounter = 0;
			
			TreebankLanguagePack tlp = new PennTreebankLanguagePack();
			GrammaticalStructureFactory gsf = tlp.grammaticalStructureFactory();
			WordStemmer ls = new WordStemmer();
			int counttt = 0;
			
			Reader reader = new StringReader(line);
			DocumentPreprocessor dp = new DocumentPreprocessor(reader);
			
			Iterator<List<HasWord>> it = dp.iterator();
			List<HasWord> sentence = null;
			while (it.hasNext()) {
				sentence = it.next();
			}
			counttt++;
			++sentenceCounter;
			LinkedHashSet<String> hs = new LinkedHashSet<String>();
			Tree parse = lp.apply(sentence);
			
			List<Tree> phraseList=new ArrayList<Tree>();
			for (Tree subtree: parse)
		    {

		      if(subtree.label().value().equals("NP"))
		      {
		        phraseList.add(subtree);
		        subtree.pennString();
		      }
		    }
			 
			
			GrammaticalStructure gs = gsf.newGrammaticalStructure(parse);
			Collection tdl = gs.typedDependencies();
			
			
			
			
			int i = 0;
			int arraySize = 0;
			
			
			/*
			 * calculate array size
			 */
			for( Iterator<TypedDependency> iter = tdl.iterator(); iter.hasNext(); ) {
				TypedDependency var = iter.next();
				TreeGraphNode dep = var.dep();
				TreeGraphNode gov = var.gov();
				// All useful information for a node in the tree
				String dependencyType = var.reln().getShortName();
				int Token_ID = var.dep().index();
				int Parent_ID = var.gov().index();
				String token = var.dep().pennString();
				token = token.substring(0,token.length()-2); 
				
				if(i == tdl.size()-1){
					arraySize = Token_ID+1;
				}
				++i;
			}
			String[][] names = new String[arraySize][4];
			for(int j = 0 ; j <arraySize ; j++){
				for(int k = 0 ; k < 4 ; k++){
					names[j][k] = "";
				}
			}
			int c = 0;
			int BeginofToken = 0;
			int EndofToken = 0;
			
			for( Iterator<TypedDependency> iter = tdl.iterator(); iter.hasNext(); ) {
				TypedDependency var = iter.next();
				
				TreeGraphNode dep = var.dep();
				TreeGraphNode gov = var.gov();
				// All useful information for a node in the tree
				String dependencyType = var.reln().getShortName();
				int Token_ID = var.dep().index();
				int Parent_ID = var.gov().index();
				String token = var.dep().pennString();
				token = token.substring(0,token.length()-2);
				
				names[Token_ID][0] = token;
				names[Token_ID][1] = String.valueOf(Token_ID);
				names[Token_ID][2] = String.valueOf(Parent_ID);
				names[Token_ID][3] = dependencyType;
				
				ArrayList<Tree>temp = new ArrayList<Tree>();
				
				if(c==0){
					BeginofToken = Token_ID;
				}
				++c;
			}
			
			EndofToken = arraySize -1; 
			
			/*
			 * location of root
			 */
			String ROOT = "";
			String ROOT_Node_ID = "";
			for(int q = 0 ; q < arraySize ; q++){
				if(names[q][3].equals("root")){
					ROOT = names[q][0];
					ROOT_Node_ID = names[q][1];
				}
			}
			
			
			
			LinkedHashSet<String> Extracted = new LinkedHashSet<String>();
			for(int q = 0 ; q < arraySize ; q++){
					if(!names[q][2].equals("")){
						
						if(names[q][3].equals("nsubj") || names[q][3].equals("dobj") || names[q][3].equals("prep") || names[q][3].equals("nsubjpass")){
							int min = Integer.valueOf(names[q][1]);
							int max = Integer.valueOf(names[q][1]);
							int FinishCount = 0;
							SortedSet set = new TreeSet();
							set.add(Integer.valueOf(names[q][1]));
							while(true){
								
								int No = 0;
								for(int p = 1 ; p < arraySize ; p++){
									if(names[p][2].equals("")){
										continue;
									}
									if(Integer.valueOf(names[p][2]) == max){
										if(set.contains(Integer.valueOf(names[p][1]))){
											++FinishCount;
										}else{
											set.add(Integer.valueOf(names[p][1]));
										}
										++No;
									}
									
									else if(max == arraySize-1){
										++FinishCount;
									}
								}
								//decide max value
								max = Integer.valueOf(String.valueOf(set.last()));
								
								if(FinishCount > 0){
									break;
								}
								
								if(No == 0){
									break;
								}
							}
							//extract noun phrases
							int start = Integer.valueOf(String.valueOf(set.first()));
							int end = Integer.valueOf(String.valueOf(set.last()));
							String NounPhrase = "";
							for(int Start = start ; Start <= end ; Start++){
								NounPhrase += names[Start][0] + " ";
							}
							Extracted.add(String.valueOf(start) +"#"+ String.valueOf(end) + "#" + NounPhrase);
						}
				}
			}
			
			for(String h : Extracted){
				String[] contents = h.split("#");
				for(int k = Integer.valueOf(contents[0]) ; k <= Integer.valueOf(contents[1]) ; k++){
					String plantPart = "";
					String ChemicalPart = "";
					String Trigger = "";
					String LeftHand = "";
					String RightHand = "";
					String MiddleHand = "";
					if(names[k][3].equals("prep")){
						MiddleHand = names[k][0].trim();
						Trigger = MiddleHand;
						
						for(int k1 = Integer.valueOf(contents[0]) ; k1 < k ; k1++){
							if(names[k1][0].length() > 0){
								LeftHand += names[k1][0].trim() + " ";
							}
						}
						
						for(int k1 = k+1 ; k1 <= Integer.valueOf(contents[1]) ; k1++){
							if(names[k1][0].length() > 0){
								RightHand += names[k1][0].trim() + " ";
							}
						}
						
					}
					
					//Predicted results as follows: <Chemical in plant>
					if(LeftHand.length() > 0 && RightHand.length() > 0){
						int c_count = 0;
						int p_count = 0;
						
						for(String s : chemical){
							String[] chemical_split = s.split("_");
							if(LeftHand.toLowerCase().contains(chemical_split[0].toLowerCase())){
								
								++c_count;
								ChemicalPart +=  s + "|";
							}
						}
						
						for(String s : plant){
							String[] plant_split = s.split("_");
							if(RightHand.toLowerCase().contains(plant_split[0].toLowerCase())){
								++p_count;
								plantPart += s + "|";
							}
						}
						
						if(c_count > 0 && p_count > 0){
							PrepResult.add(plantPart + "\t" + ChemicalPart + "\t" + Trigger + "\t" + line + "\t" + PMID + "\t"+ plantStartEnd + "\t" + chemicalStartEnd);
						}
						
					}
					
					//Predicted results as follows: <plant as chemical source>
					if(LeftHand.length() > 0 && RightHand.length() > 0 && Trigger.equals("as")){
						int c_count = 0;
						int p_count = 0;
						
						for(String s : chemical){
							String[] chemical_split = s.split("_");
							if(RightHand.toLowerCase().contains(chemical_split[0].toLowerCase())){
								++c_count;
								ChemicalPart +=  s + "|";
							}
						}
						
						
						for(String s : plant){
							String[] plant_split = s.split("_");
							if(LeftHand.toLowerCase().contains(plant_split[0].toLowerCase())){
								++p_count;
								plantPart += s + "|";
							}
						}
						
						if(c_count > 0 && p_count > 0){
							PrepResult.add(plantPart + "\t" + ChemicalPart + "\t" + Trigger + "\t" + line + "\t" + PMID + "\t"+ plantStartEnd + "\t" + chemicalStartEnd);
						}
					}
				}
			}
			return PrepResult;
	}
}
