package Rule_based_module;

import java.io.BufferedWriter;
import java.io.FileWriter;
import java.io.IOException;
import java.io.Reader;
import java.io.StringReader;
import java.util.ArrayList;
import java.util.Arrays;
import java.util.Collection;
import java.util.Iterator;
import java.util.LinkedHashSet;
import java.util.List;
import java.util.SortedSet;
import java.util.TreeSet;

import edu.stanford.nlp.ling.HasWord;
import edu.stanford.nlp.parser.lexparser.LexicalizedParser;
import edu.stanford.nlp.process.DocumentPreprocessor;
import edu.stanford.nlp.trees.GrammaticalStructure;
import edu.stanford.nlp.trees.GrammaticalStructureFactory;
import edu.stanford.nlp.trees.PennTreebankLanguagePack;
import edu.stanford.nlp.trees.Tree;
import edu.stanford.nlp.trees.TreeGraphNode;
import edu.stanford.nlp.trees.TreebankLanguagePack;
import edu.stanford.nlp.trees.TypedDependency;
import edu.stanford.nlp.trees.WordStemmer;

public class VerbalTriger_Rule {
	
	static final List<String> transitive = Arrays.asList(
			//When active : plant transitive chemical
			//When passive : chemical transitive plant
			
			"contain","contains","contained",
			"have","has","had",
			"involve","involves","involved",
			"incorporate","incorporates","incorporated",
			"possess","possesses","possessed",
			"encompass","encompasses","encompassed",
			"subsume","subsumes","subsumed",
			"comprise","comprises","comprised",
			"embody","embodies","embodied",
			"embrace","embraces","embraced",
			"include","includes","included",
			"cover","covers","covered",
			"compose","composes","composed",
			"originate","originates","originated",
			"produce","produces","produced",
			"derive","derives","derived",
			"accumulate","accumulates","accumulated",
			"release","releases","released"
			
			);
	
	static final List<String> Onlypassive = Arrays.asList(
			//When passive : chemical transitive plant
			"contained",
			"involved",
			"incorporated",
			"possessed",
			"encompassed",
			"subsumed",
			"comprised",
			"embodied",
			"embraced",
			"included",
			"covered",
			"composed",
			"produced",
			"originated",
			"derived",
			"accumulated",
			"released",
			"isolated",
			"extracted",
			"separated",
			"detached",
			"split",
			"segregated",
			"obtained",
			"found",
			"gained",
			"discovered",
			"uncovered",
			"identified"
			);
	
	static final List<String> intransitive = Arrays.asList(
			//plant intransitive prep chemical
			"consist","consists"				
			);
	public static LinkedHashSet<String> VerbalTrigger(LexicalizedParser lp, String line, String PMID, LinkedHashSet<String> plant, LinkedHashSet<String> chemical, String plantStartEnd, String chemicalStartEnd) throws IOException {
		LinkedHashSet<String> VerbalResult = new LinkedHashSet<String>();
		int sentenceCounter = 0;
		
		TreebankLanguagePack tlp = new PennTreebankLanguagePack();
		GrammaticalStructureFactory gsf = tlp.grammaticalStructureFactory();
		WordStemmer ls = new WordStemmer();
		Reader reader = new StringReader(line);
		DocumentPreprocessor dp = new DocumentPreprocessor(reader);
		
		Iterator<List<HasWord>> it = dp.iterator();
		List<HasWord> sentence = null;
		while (it.hasNext()) {
			sentence = it.next();
		}
		++sentenceCounter;
		LinkedHashSet<String> hs = new LinkedHashSet<String>();
		Tree parse = lp.apply(sentence);
		
		List<Tree> phraseList=new ArrayList<Tree>();
		 
		
		GrammaticalStructure gs = gsf.newGrammaticalStructure(parse);
		Collection tdl = gs.typedDependencies();
		
		
		int i = 0;
		int arraySize = 0;
		
		
		/*
		 * array size ���
		 */
		for( Iterator<TypedDependency> iter = tdl.iterator(); iter.hasNext(); ) {
			TypedDependency var = iter.next();
			TreeGraphNode dep = var.dep();
			TreeGraphNode gov = var.gov();
			// All useful information for a node in the tree
			String dependencyType = var.reln().getShortName();
			int Token_ID = var.dep().index();
			int Parent_ID = var.gov().index();
			String token = var.dep().pennString();
			token = token.substring(0,token.length()-2); 
			
			if(i == tdl.size()-1){
				arraySize = Token_ID+1;
			}
			++i;
		}
		String[][] names = new String[arraySize][4];
		for(int j = 0 ; j <arraySize ; j++){
			for(int k = 0 ; k < 4 ; k++){
				names[j][k] = "";
			}
		}
		int c = 0;
		int BeginofToken = 0;
		int EndofToken = 0;
		
		for( Iterator<TypedDependency> iter = tdl.iterator(); iter.hasNext(); ) {
			TypedDependency var = iter.next();
			
			TreeGraphNode dep = var.dep();
			TreeGraphNode gov = var.gov();
			// All useful information for a node in the tree
			String dependencyType = var.reln().getShortName();
			int Token_ID = var.dep().index();
			int Parent_ID = var.gov().index();
			String token = var.dep().pennString();
			token = token.substring(0,token.length()-2);
			
			names[Token_ID][0] = token;
			names[Token_ID][1] = String.valueOf(Token_ID);
			names[Token_ID][2] = String.valueOf(Parent_ID);
			names[Token_ID][3] = dependencyType;
			
			ArrayList<Tree>temp = new ArrayList<Tree>();
			
			if(c==0){
				BeginofToken = Token_ID;
			}
			++c;
		}
		
		EndofToken = arraySize -1; 
		

		/*
		 * Location of root
		 */
		String plantMention = "";
		String ChemicalMention = "";
		
		String plantPart_nsubj = "";
		String ChemicalPart_dobj = "";
		
		String ChemicalPart_nsubjpass = "";
		String plantPart_prep = "";
		
		String ROOT_Mention = "";
		String ROOT_Node_ID = "";
		String ROOT_Parent_Node_ID = "";
		//Check <Root> , <Ccomp>, <Xcomp>
		for(int q = 1 ; q < arraySize ; q++){
			/*
			 * ROOT = Verb
			 */
			if(names[q][3].equals("root") || names[q][3].equals("ccomp")){
				ROOT_Mention = names[q][0];
				ROOT_Node_ID = names[q][1];
				//active && passive
				int nsubjCount = 0;
				int dobjCount = 0;
				int nsubjpasssCount = 0;
				int prepCount = 0;
				/*
				 * transitive
				 */
				for(String term : transitive){
					if(ROOT_Mention.toLowerCase().equals(term.toLowerCase())){
						for(int p = 1 ; p < arraySize ; p++){
							if(names[p][2].equals(ROOT_Node_ID)  && names[p][3].equals("nsubj")){
								int min = Integer.valueOf(names[p][1]);
								int max = Integer.valueOf(names[p][1]);
								int FinishCount = 0;
								SortedSet set = new TreeSet();
								set.add(Integer.valueOf(names[p][1]));
								while(true){
									int No = 0;
									for(int k = 1 ; k < arraySize ; k++){
										if(names[k][2].equals("")){
											continue;
										}
										if(Integer.valueOf(names[k][2]) == max){
											if(set.contains(Integer.valueOf(names[k][1]))){
												++FinishCount;
											}else{
												set.add(Integer.valueOf(names[k][1]));
											}
											++No;
										}
										
										else if(max == arraySize-1){
											++FinishCount;
										}
									}
									//decide max value
									max = Integer.valueOf(String.valueOf(set.last()));
									if(FinishCount > 0){
										break;
									}
									if(No == 0){
										break;
									}
								}
								//extract noun phrases
								int start = Integer.valueOf(String.valueOf(set.first()));
								int end = Integer.valueOf(String.valueOf(set.last()));
								String NounPhrase = "";
								for(int Start = start ; Start <= end ; Start++){
									NounPhrase += names[Start][0] + " ";
								}
								plantPart_nsubj = NounPhrase;
								
								++nsubjCount;
							}
							if(names[p][2].equals(ROOT_Node_ID) && names[p][3].equals("dobj")){
								int min = Integer.valueOf(names[p][1]);
								int max = Integer.valueOf(names[p][1]);
								int FinishCount = 0;
								SortedSet set = new TreeSet();
								set.add(Integer.valueOf(names[p][1]));
								while(true){
									int No = 0;
									for(int k = 1 ; k < arraySize ; k++){
										if(names[k][2].equals("")){
											continue;
										}
										if(Integer.valueOf(names[k][2]) == max){
											if(set.contains(Integer.valueOf(names[k][1]))){
												++FinishCount;
											}else{
												set.add(Integer.valueOf(names[k][1]));
											}
											++No;
										}
										
										else if(max == arraySize-1){
											++FinishCount;
										}
									}
									//decide max value
									max = Integer.valueOf(String.valueOf(set.last()));
									if(FinishCount > 0){
										break;
									}
									if(No == 0){
										break;
									}
								}
								//extract noun phrases
								int start = Integer.valueOf(String.valueOf(set.first()));
								int end = Integer.valueOf(String.valueOf(set.last()));
								String NounPhrase = "";
								for(int Start = start ; Start <= end ; Start++){
									NounPhrase += names[Start][0] + " ";
								}
								ChemicalPart_dobj = NounPhrase;
								
								++dobjCount;
							}
							if(names[p][2].equals(ROOT_Node_ID) && names[p][3].equals("nsubjpass")){
								int min = Integer.valueOf(names[p][1]);
								int max = Integer.valueOf(names[p][1]);
								int FinishCount = 0;
								SortedSet set = new TreeSet();
								set.add(Integer.valueOf(names[p][1]));
								while(true){
									int No = 0;
									for(int k = 1 ; k < arraySize ; k++){
										if(names[k][2].equals("")){
											continue;
										}
										if(Integer.valueOf(names[k][2]) == max){
											if(set.contains(Integer.valueOf(names[k][1]))){
												++FinishCount;
											}else{
												set.add(Integer.valueOf(names[k][1]));
											}
											++No;
										}
										
										else if(max == arraySize-1){
											++FinishCount;
										}
									}
									//decide max value
									max = Integer.valueOf(String.valueOf(set.last()));
									if(FinishCount > 0){
										break;
									}
									if(No == 0){
										break;
									}
								}
								//extract noun phrases
								int start = Integer.valueOf(String.valueOf(set.first()));
								int end = Integer.valueOf(String.valueOf(set.last()));
								String NounPhrase = "";
								for(int Start = start ; Start <= end ; Start++){
									NounPhrase += names[Start][0] + " ";
								}
								ChemicalPart_nsubjpass = NounPhrase;
								++nsubjpasssCount;
							}
							if(names[p][2].equals(ROOT_Node_ID) && names[p][3].equals("prep")){
								int min = Integer.valueOf(names[p][1]);
								int max = Integer.valueOf(names[p][1]);
								int FinishCount = 0;
								SortedSet set = new TreeSet();
								set.add(Integer.valueOf(names[p][1]));
								while(true){
									int No = 0;
									for(int k = 1 ; k < arraySize ; k++){
										if(names[k][2].equals("")){
											continue;
										}
										if(Integer.valueOf(names[k][2]) == max){
											if(set.contains(Integer.valueOf(names[k][1]))){
												++FinishCount;
											}else{
												set.add(Integer.valueOf(names[k][1]));
											}
											++No;
										}
										
										else if(max == arraySize-1){
											++FinishCount;
										}
									}
									//decide max value
									max = Integer.valueOf(String.valueOf(set.last()));
									if(FinishCount > 0){
										break;
									}
									if(No == 0){
										break;
									}
								}
								//extract noun phrases
								int start = Integer.valueOf(String.valueOf(set.first()));
								int end = Integer.valueOf(String.valueOf(set.last()));
								String NounPhrase = "";
								for(int Start = start ; Start <= end ; Start++){
									NounPhrase += names[Start][0] + " ";
								}
								plantPart_prep = NounPhrase;
								++prepCount;
							}
						}
						
						//Predicted results as follows: <plant contains Chemicals>
						if(nsubjCount > 0 && dobjCount > 0){
							int h_count = 0;
							int c_count = 0;
							
							for(String s : plant){
								String[] plant_split = s.split("_");
								if(plantPart_nsubj.toLowerCase().contains(plant_split[0].toLowerCase())){
									plantMention += s + "|";
									++h_count;
								}
							}
							for(String s : chemical){
								String[] chemical_split = s.split("_");
								if(ChemicalPart_dobj.toLowerCase().contains(chemical_split[0].toLowerCase())){
									ChemicalMention += s + "|";
									++c_count;
								}
							}
							if(h_count > 0 && c_count > 0){
								VerbalResult.add(plantMention + "\t" + ChemicalMention + "\t" + term + "\t" + line +"\t"+ PMID + "\t"+ plantStartEnd + "\t" + chemicalStartEnd);
							}
						}
						//Predicted results as follows: <Chemical is contained in plant>
						else if(nsubjpasssCount > 0 && prepCount > 0){
							int h_count = 0;
							int c_count = 0;
							
							for(String s : plant){
								String[] plant_split = s.split("_");
								if(plantPart_prep.toLowerCase().contains(plant_split[0].toLowerCase())){
									plantMention += s + "|";
									++h_count;
								}
							}
							for(String s : chemical){
								String[] chemical_split = s.split("_");
								if(ChemicalPart_nsubjpass.toLowerCase().contains(chemical_split[0].toLowerCase())){
									ChemicalMention += s + "|";
									++c_count;
								}
							}
							if(h_count > 0 && c_count > 0){
								VerbalResult.add(plantMention + "\t" + ChemicalMention + "\t" + term + "\t" + line +"\t"+ PMID + "\t"+ plantStartEnd + "\t" + chemicalStartEnd);
							}
						}
						break;
					}
				}
				
				nsubjCount = 0;
				dobjCount = 0;
				nsubjpasssCount = 0;
				prepCount = 0;
				/*
				 * Onlypassive
				 */
				for(String term : Onlypassive){
					if(ROOT_Mention.toLowerCase().equals(term.toLowerCase())){
						for(int p = 1 ; p < arraySize ; p++){
							if(names[p][2].equals(ROOT_Node_ID) && names[p][3].equals("nsubjpass")){
								int min = Integer.valueOf(names[p][1]);
								int max = Integer.valueOf(names[p][1]);
								int FinishCount = 0;
								SortedSet set = new TreeSet();
								set.add(Integer.valueOf(names[p][1]));
								while(true){
									int No = 0;
									for(int k = 1 ; k < arraySize ; k++){
										if(names[k][2].equals("")){
											continue;
										}
										if(Integer.valueOf(names[k][2]) == max){
											if(set.contains(Integer.valueOf(names[k][1]))){
												++FinishCount;
											}else{
												set.add(Integer.valueOf(names[k][1]));
											}
											++No;
										}
										
										else if(max == arraySize-1){
											++FinishCount;
										}
									}
									//decide max value
									max = Integer.valueOf(String.valueOf(set.last()));
									if(FinishCount > 0){
										break;
									}
									if(No == 0){
										break;
									}
								}
								//extract noun phrases
								int start = Integer.valueOf(String.valueOf(set.first()));
								int end = Integer.valueOf(String.valueOf(set.last()));
								String NounPhrase = "";
								for(int Start = start ; Start <= end ; Start++){
									NounPhrase += names[Start][0] + " ";
								}
								ChemicalPart_nsubjpass = NounPhrase;
								++nsubjpasssCount;
							}
							if(names[p][2].equals(ROOT_Node_ID) && names[p][3].equals("prep")){
								int min = Integer.valueOf(names[p][1]);
								int max = Integer.valueOf(names[p][1]);
								int FinishCount = 0;
								SortedSet set = new TreeSet();
								set.add(Integer.valueOf(names[p][1]));
								while(true){
									int No = 0;
									for(int k = 1 ; k < arraySize ; k++){
										if(names[k][2].equals("")){
											continue;
										}
										if(Integer.valueOf(names[k][2]) == max){
											if(set.contains(Integer.valueOf(names[k][1]))){
												++FinishCount;
											}else{
												set.add(Integer.valueOf(names[k][1]));
											}
											++No;
										}
										
										else if(max == arraySize-1){
											++FinishCount;
										}
									}
									//decide max value
									max = Integer.valueOf(String.valueOf(set.last()));
									if(FinishCount > 0){
										break;
									}
									if(No == 0){
										break;
									}
								}
								//extract noun phrases
								int start = Integer.valueOf(String.valueOf(set.first()));
								int end = Integer.valueOf(String.valueOf(set.last()));
								String NounPhrase = "";
								for(int Start = start ; Start <= end ; Start++){
									NounPhrase += names[Start][0] + " ";
								}
								plantPart_prep = NounPhrase;
								++prepCount;
								break;
							}
						}
						if(nsubjpasssCount > 0 && prepCount > 0){
							int h_count = 0;
							int c_count = 0;
							
							for(String s : plant){
								String[] plant_split = s.split("_");
								if(plantPart_prep.toLowerCase().contains(plant_split[0].toLowerCase())){
									plantMention += s + "|";
									++h_count;
								}
							}
							for(String s : chemical){
								String[] chemical_split = s.split("_");
								if(ChemicalPart_nsubjpass.toLowerCase().contains(chemical_split[0].toLowerCase())){
									ChemicalMention += s + "|";
									++c_count;
								}
							}
							if(h_count > 0 && c_count > 0){
								VerbalResult.add(plantMention + "\t" + ChemicalMention + "\t" + term + "\t" + line +"\t"+ PMID + "\t"+ plantStartEnd + "\t" + chemicalStartEnd);
							}
						}
						break;
					}
				}
				
				nsubjCount = 0;
				dobjCount = 0;
				nsubjpasssCount = 0;
				prepCount = 0;
				/*
				 * intransitive
				 */
				for(String term : intransitive){
					if(ROOT_Mention.toLowerCase().equals(term.toLowerCase())){
						for(int p = 1 ; p < arraySize ; p++){
							if(names[p][2].equals(ROOT_Node_ID)  && names[p][3].equals("nsubj")){
								int min = Integer.valueOf(names[p][1]);
								int max = Integer.valueOf(names[p][1]);
								int FinishCount = 0;
								SortedSet set = new TreeSet();
								set.add(Integer.valueOf(names[p][1]));
								while(true){
									int No = 0;
									for(int k = 1 ; k < arraySize ; k++){
										if(names[k][2].equals("")){
											continue;
										}
										if(Integer.valueOf(names[k][2]) == max){
											if(set.contains(Integer.valueOf(names[k][1]))){
												++FinishCount;
											}else{
												set.add(Integer.valueOf(names[k][1]));
											}
											++No;
										}
										
										else if(max == arraySize-1){
											++FinishCount;
										}
									}
									//decide max value.
									max = Integer.valueOf(String.valueOf(set.last()));
									if(FinishCount > 0){
										break;
									}
									if(No == 0){
										break;
									}
								}
								//extract noun phrases
								int start = Integer.valueOf(String.valueOf(set.first()));
								int end = Integer.valueOf(String.valueOf(set.last()));
								String NounPhrase = "";
								for(int Start = start ; Start <= end ; Start++){
									NounPhrase += names[Start][0] + " ";
								}
								plantPart_nsubj = NounPhrase;
								++nsubjCount;
							}
							
							if(names[p][2].equals(ROOT_Node_ID) && names[p][3].equals("prep")){
								int min = Integer.valueOf(names[p][1]);
								int max = Integer.valueOf(names[p][1]);
								int FinishCount = 0;
								SortedSet set = new TreeSet();
								set.add(Integer.valueOf(names[p][1]));
								while(true){
									int No = 0;
									for(int k = 1 ; k < arraySize ; k++){
										if(names[k][2].equals("")){
											continue;
										}
										if(Integer.valueOf(names[k][2]) == max){
											if(set.contains(Integer.valueOf(names[k][1]))){
												++FinishCount;
											}else{
												set.add(Integer.valueOf(names[k][1]));
											}
											++No;
										}
										
										else if(max == arraySize-1){
											++FinishCount;
										}
									}
									//decide max value
									max = Integer.valueOf(String.valueOf(set.last()));
									if(FinishCount > 0){
										break;
									}
									if(No == 0){
										break;
									}
								}
								//extract noun phrases
								int start = Integer.valueOf(String.valueOf(set.first()));
								int end = Integer.valueOf(String.valueOf(set.last()));
								String NounPhrase = "";
								for(int Start = start ; Start <= end ; Start++){
									NounPhrase += names[Start][0] + " ";
								}
								ChemicalPart_dobj = NounPhrase;
								++prepCount;
								break;
							}
							
							
							
						}
						//Predicted results as follows: <plant consists of Chemicals>
						if(nsubjCount > 0 && prepCount > 0){
							int h_count = 0;
							int c_count = 0;
							
							for(String s : plant){
								String[] plant_split = s.split("_");
								if(plantPart_nsubj.toLowerCase().contains(plant_split[0].toLowerCase())){
									plantMention += s + "|";
									++h_count;
								}
							}
							for(String s : chemical){
								String[] chemical_split = s.split("_");
								if(ChemicalPart_dobj.toLowerCase().contains(chemical_split[0].toLowerCase())){
									ChemicalMention += s + "|";
									++c_count;
								}
							}
							if(h_count > 0 && c_count > 0){
								VerbalResult.add(plantMention + "\t" + ChemicalMention + "\t" + term + "\t" + line +"\t"+ PMID + "\t"+ plantStartEnd + "\t" + chemicalStartEnd);
							}
						}
						break;
					}
				}
				
				
			}
			
			
			/*
			 * xcomp = Verb
			 */
			else if(names[q][3].equals("xcomp")){
				
				ROOT_Mention = names[q][0];
				ROOT_Node_ID = names[q][1];
				ROOT_Parent_Node_ID = names[q][2];
				int nsubjCount = 0;
				int dobjCount = 0;
				int nsubjpasssCount = 0;
				int prepCount = 0;
				/*
				 * transitive
				 */
				for(String term : transitive){
					if(ROOT_Mention.toLowerCase().equals(term.toLowerCase())){
						for(int p = 1 ; p < arraySize ; p++){
							if(names[p][2].equals(ROOT_Parent_Node_ID)  && names[p][3].equals("nsubj")){
								int min = Integer.valueOf(names[p][1]);
								int max = Integer.valueOf(names[p][1]);
								int FinishCount = 0;
								SortedSet set = new TreeSet();
								set.add(Integer.valueOf(names[p][1]));
								while(true){
									int No = 0;
									for(int k = 1 ; k < arraySize ; k++){
										if(names[k][2].equals("")){
											continue;
										}
										if(Integer.valueOf(names[k][2]) == max){
											if(set.contains(Integer.valueOf(names[k][1]))){
												++FinishCount;
											}else{
												set.add(Integer.valueOf(names[k][1]));
											}
											++No;
										}
										
										else if(max == arraySize-1){
											++FinishCount;
										}
									}
									//decide max value
									max = Integer.valueOf(String.valueOf(set.last()));
									if(FinishCount > 0){
										break;
									}
									if(No == 0){
										break;
									}
								}
								//extract noun phrases
								int start = Integer.valueOf(String.valueOf(set.first()));
								int end = Integer.valueOf(String.valueOf(set.last()));
								String NounPhrase = "";
								for(int Start = start ; Start <= end ; Start++){
									NounPhrase += names[Start][0] + " ";
								}
								plantPart_nsubj = NounPhrase;
								++nsubjCount;
							}
							
							if(names[p][2].equals(ROOT_Node_ID) && names[p][3].equals("dobj")){
								int min = Integer.valueOf(names[p][1]);
								int max = Integer.valueOf(names[p][1]);
								int FinishCount = 0;
								SortedSet set = new TreeSet();
								set.add(Integer.valueOf(names[p][1]));
								while(true){
									int No = 0;
									for(int k = 1 ; k < arraySize ; k++){
										if(names[k][2].equals("")){
											continue;
										}
										if(Integer.valueOf(names[k][2]) == max){
											if(set.contains(Integer.valueOf(names[k][1]))){
												++FinishCount;
											}else{
												set.add(Integer.valueOf(names[k][1]));
											}
											++No;
										}
										
										else if(max == arraySize-1){
											++FinishCount;
										}
									}
									//decide max value
									max = Integer.valueOf(String.valueOf(set.last()));
									if(FinishCount > 0){
										break;
									}
									if(No == 0){
										break;
									}
								}
								//extract noun phrases
								int start = Integer.valueOf(String.valueOf(set.first()));
								int end = Integer.valueOf(String.valueOf(set.last()));
								String NounPhrase = "";
								for(int Start = start ; Start <= end ; Start++){
									NounPhrase += names[Start][0] + " ";
								}
								ChemicalPart_dobj = NounPhrase;
								++dobjCount;
							}
							
							if(names[p][2].equals(ROOT_Node_ID) && names[p][3].equals("nsubjpass")){
								int min = Integer.valueOf(names[p][1]);
								int max = Integer.valueOf(names[p][1]);
								int FinishCount = 0;
								SortedSet set = new TreeSet();
								set.add(Integer.valueOf(names[p][1]));
								while(true){
									int No = 0;
									for(int k = 1 ; k < arraySize ; k++){
										if(names[k][2].equals("")){
											continue;
										}
										if(Integer.valueOf(names[k][2]) == max){
											if(set.contains(Integer.valueOf(names[k][1]))){
												++FinishCount;
											}else{
												set.add(Integer.valueOf(names[k][1]));
											}
											++No;
										}
										
										else if(max == arraySize-1){
											++FinishCount;
										}
									}
									//decide max value
									max = Integer.valueOf(String.valueOf(set.last()));
									if(FinishCount > 0){
										break;
									}
									if(No == 0){
										break;
									}
								}
								//extract noun phrases
								int start = Integer.valueOf(String.valueOf(set.first()));
								int end = Integer.valueOf(String.valueOf(set.last()));
								String NounPhrase = "";
								for(int Start = start ; Start <= end ; Start++){
									NounPhrase += names[Start][0] + " ";
								}
								plantPart_nsubj = NounPhrase;
								++nsubjpasssCount;
							}
						}
						if(nsubjCount > 0 && dobjCount > 0){
							int h_count = 0;
							int c_count = 0;
							
							for(String s : plant){
								String[] plant_split = s.split("_");
								if(plantPart_nsubj.toLowerCase().contains(plant_split[0].toLowerCase())){
									plantMention += s + "|";
									++h_count;
								}
							}
							for(String s : chemical){
								String[] chemical_split = s.split("_");
								if(ChemicalPart_dobj.toLowerCase().contains(chemical_split[0].toLowerCase())){
									ChemicalMention += s + "|";
									++c_count;
								}
							}
							if(h_count > 0 && c_count > 0){
								VerbalResult.add(plantMention + "\t" + ChemicalMention + "\t" + term + "\t" + line +"\t"+ PMID + "\t"+ plantStartEnd + "\t" + chemicalStartEnd);
							}
						}
						
						else if(nsubjpasssCount > 0 && dobjCount > 0){
							int h_count = 0;
							int c_count = 0;
							
							for(String s : plant){
								String[] plant_split = s.split("_");
								if(plantPart_nsubj.toLowerCase().contains(plant_split[0].toLowerCase())){
									plantMention +=  s + "|";
									++h_count;
								}
							}
							for(String s : chemical){
								String[] chemical_split = s.split("_");
								if(ChemicalPart_dobj.toLowerCase().contains(chemical_split[0].toLowerCase())){
									ChemicalMention +=  s + "|";
									++c_count;
								}
							}
							if(h_count > 0 && c_count > 0){
								VerbalResult.add(plantMention + "\t" + ChemicalMention + "\t" + term + "\t" + line +"\t"+ PMID + "\t"+ plantStartEnd + "\t" + chemicalStartEnd);
							}
						}
						break;
					}
				}
				
				
			}
		}
		return VerbalResult;
	}
}
