package Rule_based_module;


import java.io.IOException;
import java.util.LinkedHashSet;

import edu.stanford.nlp.parser.lexparser.LexicalizedParser;

public class CompoundNounTrigger_Rule {
	public static LinkedHashSet<String> CompoundNounTrigger(LexicalizedParser lp, String line, String PMID, LinkedHashSet<String> plant, LinkedHashSet<String> chemical, String plantStartEnd, String chemicalStartEnd) throws IOException {
		LinkedHashSet<String> CompNounResult = new LinkedHashSet<String>();
		/*
		 * 
		 * Check if the sentence has the same structure of compoundnount trigger rule.
		 * 
		 */
		String plant_chemical = "";
		for(String s : plant){
			String[] plant_split = s.split("_");
			for(String c : chemical){
				String[] chemical_split = c.split("_");
				plant_chemical = plant_split[0].toLowerCase() + " " + chemical_split[0].toLowerCase();
				if(line.toLowerCase().contains(plant_chemical)){
					CompNounResult.add(s + "\t" + c + "\t" + "contain" + "\t" + line +"\t" + PMID + "\t"+ plantStartEnd + "\t" + chemicalStartEnd);
				}
			}
		}
		return CompNounResult;
	}
}
